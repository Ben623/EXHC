﻿#Disclaimer:
#The sample scripts are not supported under any Microsoft standard support program or service. The sample scripts are provided AS IS without warranty of any kind. Microsoft further disclaims all implied warranties including, without limitation, any implied warranties of merchantability or of fitness for a particular purpose. The entire risk arising out of the use or performance of the sample scripts and documentation remains with you. In no event shall Microsoft, its authors, or anyone else involved in the creation, production, or delivery of the scripts be liable for any damages whatsoever (including, without limitation, damages for loss of business profits, business interruption, loss of business information, or other pecuniary loss) arising out of the use of or inability to use the sample scripts or documentation, even if Microsoft has been advised of the possibility of such damages.


### Parameters that can be changed ###

# CSV path with the users list #
$ImportFile = "C:\Temp\users.csv"
################################

# Start date for email report - Change the number of days backwards #
$stdate = (get-date).AddDays(-30)
#####################################################################

# End date for email report - default is current date #
$enddate = (get-date)
#######################################################

# HTML report location and name of the email summery #
$ReportFile = "C:\Temp\total.htm"
######################################################

### End of Parameters that can be changed ###

$totaldays=(New-TimeSpan -Start $stdate -End $enddate).days
Remove-Item $ReportFile -ErrorAction SilentlyContinue

if (Get-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 -Registered -ErrorAction SilentlyContinue) { 
    Add-PSSnapin Microsoft.Exchange.Management.PowerShell.E2010 
} else { 
    Add-PSSnapin -Name Microsoft.Exchange.Management.PowerShell.Admin 
} 

$tabName = “Report”
$table = New-Object system.Data.DataTable “$tabName”

$col1 = New-Object system.Data.DataColumn "Mailbox",([string])
$col2 = New-Object system.Data.DataColumn "User Name",([string])
$col3 = New-Object system.Data.DataColumn "Total Emails Received",([string])
$col4 = New-Object system.Data.DataColumn "Total Emails Sent",([string])
 
$table.columns.add($col1)
$table.columns.add($col2)
$table.columns.add($col3)
$table.columns.add($col4)


import-csv -path $ImportFile | ForEach-Object {
$MBX=$_.Name
$Totalrec = 0
$intRec = 0
$TotalSend = 0
$intSend = 0
(Get-TransportService) | Get-MessageTrackingLog -Recipients $MBX -ResultSize Unlimited -Start $stdate -End $enddate | ForEach-Object { 
        If ($_.EventId -eq "DELIVER") {
			$intRec += $_.RecipientCount
			$Totalrec =$RecPerDay + $intRec
			}
		}

(Get-TransportService) | Get-MessageTrackingLog -Sender $MBX -ResultSize Unlimited -Start $stdate -End $enddate | ForEach-Object { 
        If ($_.EventId -eq "RECEIVE" -and $_.Source -eq "STOREDRIVER") {
			$intSend += $_.RecipientCount
			$TotalSend =$SendPerDay + $intSend
			}
		}
$usrname=(Get-Mailbox $MBX).name

        # Create a row
        $row = $table.NewRow()
  
        # Enter data in the row
        $row."Mailbox" = ($MBX)
        $row."User Name" = ($usrname)
        $row."Total Emails Received" = ($Totalrec)
        $row."Total Emails Sent" = ($Totalsend)
 
        # Add the row to the table
        $table.Rows.Add($row)

Write-Host -ForegroundColor Magenta "Total emails received for $MBX during the last $totaldays days are $Totalrec"
Write-Host -ForegroundColor Green "Total emails sent by $MBX during the last $totaldays days are $TotalSend"
Write-Host -ForegroundColor Cyan  "-----------------------------------------------------------------"
Write-Host " "
	}

# Creating head style
$Head = @"
  
<style>
  body {
    font-family: "Arial";
    font-size: 10pt;
    color: #4C607B;
    }
  th, td { 
    border: 3px solid #64bded;
    border-collapse: collapse;
    padding: 5px;
    }
  th {
    font-size: 1.2em;
    text-align: left;
    background-color: #647ded;
    color: #ffffff;
    }
  td {
    color: #000000;
    }
  .even { background-color: #ffffff; }
  .odd { background-color: #bfbfbf; }
</style>
  
"@
 
# Creating body
[string]$body = [PSCustomObject]$table | Select-Object -Property "Mailbox","User Name","Total Emails Received","Total Emails Sent" | Sort-Object -Property "User Name"  | ConvertTo-HTML -head $Head -Body "<font color=`"Black`"><h4>Total sent and received emails per mailbox  </h4></font>"    | Out-File $ReportFile
